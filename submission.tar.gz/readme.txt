Game: 2110 Last Stand
Author: Thomas Lang

This program is a GBA game where you are a spaceship defending Earth against waves of alien invaders.

You can move your spaceship with the arrow-keys.

You can shoot using the B button on the GBA or X button on an emulator.

You can reset the game using the Select button on the GBA or backspace button on an emulator.

You can move forward instruction screens using the A button on the GBA or the Z button on an emulator

Enemy ships will spawn from the top of the screen. Killing them rewards you with +1 hp and +1 score.

If an enemy ship reaches the bottom of your screen, you will lose health! 

Once you reach zero health, the game ends! Good luck and have fun!