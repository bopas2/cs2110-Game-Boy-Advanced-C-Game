/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gamebg gamebg.png 
 * Time-stamp: Thursday 11/14/2019, 05:30:26
 * 
 * Image Information
 * -----------------
 * gamebg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEBG_H
#define GAMEBG_H

extern const unsigned short gamebg[38400];
#define GAMEBG_SIZE 76800
#define GAMEBG_LENGTH 38400
#define GAMEBG_WIDTH 240
#define GAMEBG_HEIGHT 160

#endif

