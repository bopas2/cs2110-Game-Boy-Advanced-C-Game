/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 endgame endgame.png 
 * Time-stamp: Friday 11/15/2019, 02:32:56
 * 
 * Image Information
 * -----------------
 * endgame.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENDGAME_H
#define ENDGAME_H

extern const unsigned short endgame[38400];
#define ENDGAME_SIZE 76800
#define ENDGAME_LENGTH 38400
#define ENDGAME_WIDTH 240
#define ENDGAME_HEIGHT 160

#endif

