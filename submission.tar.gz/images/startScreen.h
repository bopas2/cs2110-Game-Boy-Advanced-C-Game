/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 startScreen start_screen.png 
 * Time-stamp: Thursday 11/14/2019, 01:47:17
 * 
 * Image Information
 * -----------------
 * start_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTSCREEN_H
#define STARTSCREEN_H

extern const unsigned short start_screen[38400];
#define START_SCREEN_SIZE 76800
#define START_SCREEN_LENGTH 38400
#define START_SCREEN_WIDTH 240
#define START_SCREEN_HEIGHT 160

#endif

