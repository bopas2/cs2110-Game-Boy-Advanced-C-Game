/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=17x17 player player.png 
 * Time-stamp: Thursday 11/14/2019, 02:33:27
 * 
 * Image Information
 * -----------------
 * player.png 17@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_H
#define PLAYER_H

extern const unsigned short player[289];
#define PLAYER_SIZE 578
#define PLAYER_LENGTH 289
#define PLAYER_WIDTH 17
#define PLAYER_HEIGHT 17

#endif

