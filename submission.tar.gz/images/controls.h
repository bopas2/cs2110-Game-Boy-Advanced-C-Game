/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 controls controls.png 
 * Time-stamp: Saturday 11/16/2019, 21:18:53
 * 
 * Image Information
 * -----------------
 * controls.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CONTROLS_H
#define CONTROLS_H

extern const unsigned short controls[38400];
#define CONTROLS_SIZE 76800
#define CONTROLS_LENGTH 38400
#define CONTROLS_WIDTH 240
#define CONTROLS_HEIGHT 160

#endif

