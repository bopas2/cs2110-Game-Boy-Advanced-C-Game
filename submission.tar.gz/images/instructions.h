/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 instructions instructions.png 
 * Time-stamp: Saturday 11/16/2019, 21:19:06
 * 
 * Image Information
 * -----------------
 * instructions.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

extern const unsigned short instructions[38400];
#define INSTRUCTIONS_SIZE 76800
#define INSTRUCTIONS_LENGTH 38400
#define INSTRUCTIONS_WIDTH 240
#define INSTRUCTIONS_HEIGHT 160

#endif

