/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=11x9 evil_ship evil_ship.png 
 * Time-stamp: Thursday 11/14/2019, 20:44:12
 * 
 * Image Information
 * -----------------
 * evil_ship.png 11@9
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EVIL_SHIP_H
#define EVIL_SHIP_H

extern const unsigned short evil_ship[99];
#define EVIL_SHIP_SIZE 198
#define EVIL_SHIP_LENGTH 99
#define EVIL_SHIP_WIDTH 11
#define EVIL_SHIP_HEIGHT 9

#endif

